# Lunarium Monorepo (Full)

This archive contains the Lunarium monorepo skeleton with implemented modules:
- packages/shared-core (crypto primitives for secp256k1 & ed25519)
- apps/mobile (React Native - onboarding & stake screens)
- apps/desktop (Electron skeleton)
- packages/daemon-manager (masternode manager + RPC client)
- docs/architecture.md

**Important:** The code is provided as-is and contains clear TODOs where chain-specific transaction formats, RPC method names, and secrets handling must be adapted to your Lunarium node implementation and security policy.

