// shared-core/src/tx.ts
// Generic transaction builder & signer helpers.
// IMPORTANT: Replace the serialisation and field names with Lunarium's actual tx format.

import { sha256Hex, signDigest } from './crypto';

export interface UnsignedTx {
  from: string;
  to: string;
  value: string; // smallest denomination
  nonce: number;
  fee?: string;
  data?: any;
}

export function canonicalize(obj: any): string {
  // Simple canonical JSON: sort keys recursively
  if (obj === null || typeof obj !== 'object') return JSON.stringify(obj);
  if (Array.isArray(obj)) return '[' + obj.map(canonicalize).join(',') + ']';
  const keys = Object.keys(obj).sort();
  return '{' + keys.map(k => JSON.stringify(k) + ':' + canonicalize(obj[k])).join(',') + '}';
}

export function txDigest(unsignedTx: UnsignedTx): string {
  const serialized = canonicalize(unsignedTx);
  return sha256Hex(serialized);
}

export async function signTx(unsignedTx: UnsignedTx, privKeyHex: string, curve: 'secp256k1' | 'ed25519') {
  const digest = txDigest(unsignedTx);
  const sigHex = await signDigest(curve, digest, privKeyHex);
  // Return a payload that contains unsignedTx + signature; adapt to network expected rawTx structure
  return {
    unsignedTx,
    signature: sigHex,
    digest
  };
}
