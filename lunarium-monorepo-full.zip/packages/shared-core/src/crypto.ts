// shared-core/src/crypto.ts
// Dual-curve support: secp256k1 (BIP32) and ed25519 (SLIP-0010 via ed25519-hd-key)
// NOTE: Adapt derivation paths and curve selection to Lunarium chain policy.

import * as bip39 from 'bip39';
import * as bip32 from 'bip32';
import { derivePath as ed25519Derive } from 'ed25519-hd-key';
import * as secp from '@noble/secp256k1';
import * as ed from '@noble/ed25519';
import { randomBytes, createHash } from 'crypto';

export type Curve = 'secp256k1' | 'ed25519';

export function generateMnemonic(strength = 256): string {
  return bip39.generateMnemonic(strength);
}

export async function mnemonicToSeed(mnemonic: string, passphrase = ''): Promise<Buffer> {
  return await bip39.mnemonicToSeed(mnemonic, passphrase);
}

export async function deriveKey(params: {
  mnemonic?: string;
  seed?: Buffer;
  curve?: Curve;
  path?: string;
}) : Promise<{ privKeyBytes: Uint8Array; pubKeyBytes: Uint8Array; privKeyHex: string; pubKeyHex: string }> {
  const curve = params.curve || 'secp256k1';
  let seed: Buffer;
  if (params.seed) seed = params.seed;
  else if (params.mnemonic) seed = await mnemonicToSeed(params.mnemonic);
  else throw new Error('Either mnemonic or seed must be provided');

  if (curve === 'secp256k1') {
    // Use BIP32 derivation (note: bip32 uses secp256k1)
    const root = bip32.fromSeed(seed);
    const path = params.path || "m/44'/60'/0'/0/0"; // default; adapt for Lunarium
    const child = root.derivePath(path);
    if (!child.privateKey) throw new Error('Cannot derive private key (secp256k1)');
    const priv = child.privateKey;
    const pub = secp.getPublicKey(priv);
    return {
      privKeyBytes: new Uint8Array(priv),
      pubKeyBytes: new Uint8Array(pub),
      privKeyHex: Buffer.from(priv).toString('hex'),
      pubKeyHex: Buffer.from(pub).toString('hex')
    };
  } else {
    // ed25519 via SLIP-0010 (ed25519-hd-key)
    const path = params.path || "m/44'/0'/0'/0'/0'"; // example; adapt to Lunarium
    const derived = ed25519Derive(path, seed.toString('hex'));
    const priv = Buffer.from(derived.key, 'hex');
    const pub = await ed.getPublicKey(priv);
    return {
      privKeyBytes: new Uint8Array(priv),
      pubKeyBytes: new Uint8Array(pub),
      privKeyHex: priv.toString('hex'),
      pubKeyHex: Buffer.from(pub).toString('hex')
    };
  }
}

// Signing utilities

export async function signDigest(curve: Curve, digestHex: string, privKeyHex: string): Promise<string> {
  const msg = Buffer.from(digestHex, 'hex');
  if (curve === 'secp256k1') {
    // noble/secp256k1 signs message hash (32 bytes)
    const sig = await secp.sign(msg, privKeyHex, { canonical: true });
    return Buffer.from(sig).toString('hex');
  } else {
    const sig = await ed.sign(msg, privKeyHex);
    return Buffer.from(sig).toString('hex');
  }
}

export function sha256Hex(input: string): string {
  return createHash('sha256').update(input).digest('hex');
}
