// packages/daemon-manager/src/server.ts
import express from 'express';
import bodyParser from 'body-parser';
import { registerRoutes } from './routes';
const app = express();
app.use(bodyParser.json());
registerRoutes(app);
const PORT = process.env.PORT || 8081;
app.listen(PORT, () => console.log(`Daemon manager listening on ${PORT}`));
