// packages/daemon-manager/src/rpcClient.ts
// Simple JSON-RPC client wrapper. Adapt method names to Lunarium node API.
import fetch from 'node-fetch';

export class RpcClient {
  url: string;
  constructor(url: string){ this.url = url; }
  async call(method: string, params: any[] = []) {
    const resp = await fetch(this.url, {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ jsonrpc:'2.0', id:1, method, params })
    });
    return resp.json();
  }

  async broadcastTx(rawTx: any) {
    return this.call('broadcast_tx', [rawTx]);
  }

  async getNonce(address: string) {
    return this.call('account_nonce', [address]);
  }

  async estimateFee(unsignedTx: any) {
    return this.call('estimate_fee', [unsignedTx]);
  }
}
