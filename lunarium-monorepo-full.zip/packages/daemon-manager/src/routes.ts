// packages/daemon-manager/src/routes.ts
import { Application, Request, Response } from 'express';
import { MnManager } from './mnManager';

const manager = new MnManager();

export function registerRoutes(app: Application) {
  app.post('/masternode/register', async (req: Request, res: Response) => {
    try {
      const { ip, port, operatorPubKey, collateralTx, operatorPrivKeyEncrypted } = req.body;
      const mn = await manager.register({ ip, port, operatorPubKey, collateralTx, operatorPrivKeyEncrypted });
      res.json({ success: true, mnId: mn.id });
    } catch (err: any) {
      res.status(500).json({ success:false, error: err.message });
    }
  });

  app.get('/masternode/:id/status', async (req: Request, res: Response) => {
    const id = req.params.id;
    const status = manager.getStatus(id);
    res.json({ success: true, status });
  });

  app.post('/masternode/:id/build-register', async (req: Request, res: Response) => {
    const id = req.params.id;
    const { signWithOperatorPrivHex } = req.body;
    try {
      const result = await manager.buildRegisterTx(id, signWithOperatorPrivHex);
      res.json({ success: true, result });
    } catch (err: any) {
      res.status(500).json({ success:false, error: err.message });
    }
  });

  app.post('/masternode/:id/heartbeat', async (req: Request, res: Response) => {
    manager.heartbeat(req.params.id);
    res.json({ success: true });
  });
}
