// packages/daemon-manager/src/mnManager.ts
import { v4 as uuidv4 } from 'uuid';
import { RpcClient } from './rpcClient';
import { deriveKey, signTx } from '@lunarium/shared-core';

// Minimal in-memory store for demo
interface MNEntry {
  id: string;
  ip: string;
  port: number;
  operatorPubKey: string;
  operatorPrivKeyEncrypted?: string; // DO NOT store raw priv keys in production
  collateralTx?: string;
  lastHeartbeat?: number;
  status?: string;
}

export class MnManager {
  private nodes: Map<string, MNEntry> = new Map();
  private rpc: RpcClient;

  constructor(rpcUrl = process.env.RPC_URL || 'https://testnet-node.example/rpc') {
    this.rpc = new RpcClient(rpcUrl);
  }

  async register(payload: { ip?:string; port?:number; operatorPubKey?:string; collateralTx?:string; operatorPrivKeyEncrypted?:string }) {
    const id = uuidv4();
    const entry: MNEntry = {
      id,
      ip: payload.ip || '127.0.0.1',
      port: payload.port || 9999,
      operatorPubKey: payload.operatorPubKey || '',
      operatorPrivKeyEncrypted: payload.operatorPrivKeyEncrypted,
      collateralTx: payload.collateralTx,
      lastHeartbeat: Date.now(),
      status: 'registered-local'
    };
    this.nodes.set(id, entry);
    return entry;
  }

  getStatus(id: string) {
    return this.nodes.get(id) || null;
  }

  heartbeat(id: string) {
    const e = this.nodes.get(id);
    if (e) e.lastHeartbeat = Date.now();
  }

  // Build register-on-chain tx and either sign locally (if operator key is available) or return unsigned payload for client signing.
  async buildRegisterTx(id: string, operatorPrivHex?: string) {
    const e = this.nodes.get(id);
    if (!e) throw new Error('MN not found');
    const unsignedTx = {
      from: e.operatorPubKey,
      to: 'masternode_registry_contract',
      value: '0',
      nonce: 0,
      fee: '0',
      data: { action: 'register_masternode', ip: e.ip, port: e.port, collateral: e.collateralTx }
    };
    // Get nonce/fee from RPC
    try {
      const nonceResp = await this.rpc.getNonce(e.operatorPubKey);
      if (nonceResp && nonceResp.result && typeof nonceResp.result.nonce !== 'undefined') {
        unsignedTx.nonce = nonceResp.result.nonce;
      }
      const feeResp = await this.rpc.estimateFee(unsignedTx);
      if (feeResp && feeResp.result && feeResp.result.fee) unsignedTx.fee = feeResp.result.fee;
    } catch (err) {
      // ignore; will rely on defaults
    }

    if (operatorPrivHex) {
      // sign locally (ONLY if operator private key is provided and secured)
      const signed = await signTx(unsignedTx, operatorPrivHex, 'secp256k1');
      const broadcastResp = await this.rpc.broadcastTx(signed);
      return { signed, broadcastResp };
    } else {
      // return unsigned payload for client to sign
      return { unsignedTx };
    }
  }
}
