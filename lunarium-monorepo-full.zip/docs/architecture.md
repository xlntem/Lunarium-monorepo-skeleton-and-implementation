# Lunarium Wallet Architecture (Full ZIP)

See the README and the in-code comments for instructions. Important TODOs:
- Replace RPC method names with your Lunarium node's methods (account_nonce, estimate_fee, broadcast_tx)
- Replace tx serialization in shared-core/tx.ts with Lunarium canonical tx format
- Do not store private keys in daemon in plaintext — implement secure enclave or require client signatures.

