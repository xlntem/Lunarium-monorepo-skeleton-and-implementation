// apps/mobile/src/screens/Onboarding.tsx
import React, { useState } from 'react';
import { View, Text, Button, Alert } from 'react-native';
import * as Keychain from 'react-native-keychain';
import { generateMnemonic } from '@lunarium/shared-core';

export default function Onboarding({ navigation }: any) {
  const [mnemonic, setMnemonic] = useState<string | null>(null);

  const createWallet = async () => {
    const m = generateMnemonic();
    setMnemonic(m);
    // Save to secure storage - in production encrypt with user password
    await Keychain.setGenericPassword('lunarium', m, { service: 'lunarium-mnemonic' });
    Alert.alert('Carteira criada', 'Anote sua seed em um local seguro.');
    navigation.replace('Stake');
  };

  const restoreWallet = async () => {
    const creds = await Keychain.getGenericPassword({ service: 'lunarium-mnemonic' });
    if (creds) {
      Alert.alert('Restaurado', 'Carteira restaurada com sucesso.');
      navigation.replace('Stake');
    } else {
      Alert.alert('Erro', 'Nenhuma seed encontrada no dispositivo.');
    }
  };

  return (
    <View style={{flex:1, padding:20, justifyContent:'center'}}>
      <Text style={{fontSize:26, marginBottom:20}}>Lunarium Wallet</Text>
      <Button title="Criar nova carteira" onPress={createWallet} />
      <View style={{height:16}}/>
      <Button title="Restaurar carteira" onPress={restoreWallet} />
      {mnemonic ? (
        <View style={{marginTop:20}}>
          <Text style={{fontWeight:'bold'}}>Anote sua seed:</Text>
          <Text selectable>{mnemonic}</Text>
        </View>
      ) : null}
    </View>
  );
}
