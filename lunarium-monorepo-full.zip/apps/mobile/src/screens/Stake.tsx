// apps/mobile/src/screens/Stake.tsx
import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert } from 'react-native';
import * as Keychain from 'react-native-keychain';
import { deriveKey, signTx, UnsignedTx } from '@lunarium/shared-core';

const RPC_URL = process.env.RPC_URL || 'https://testnet-node.example/rpc'; // adapt

export default function Stake() {
  const [amount, setAmount] = useState('');
  const [validator, setValidator] = useState('');
  const [curve, setCurve] = useState<'secp256k1'|'ed25519'>('secp256k1');
  const [loading, setLoading] = useState(false);

  async function handleStake() {
    if (!amount || !validator) return Alert.alert('Preencha amount e validator');
    setLoading(true);
    try {
      const creds = await Keychain.getGenericPassword({ service: 'lunarium-mnemonic' });
      if (!creds) throw new Error('No seed found');
      const mnemonic = creds.password;
      // derive key
      const { privKeyHex, pubKeyHex } = await deriveKey({ mnemonic, curve });
      // Build unsigned tx - adapt fields to Lunarium tx format
      const unsignedTx: UnsignedTx = {
        from: pubKeyHex,
        to: validator,
        value: amount,
        nonce: 0,
        fee: '0', // TODO: get fee estimate
        data: { type: 'stake' }
      };
      // Sign tx
      const signed = await signTx(unsignedTx, privKeyHex, curve);
      // Broadcast to RPC
      const resp = await fetch(RPC_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          method: 'broadcast_tx',
          params: [signed],
          id: 1
        })
      });
      const j = await resp.json();
      setLoading(false);
      Alert.alert('Broadcast result', JSON.stringify(j));
    } catch (err: any) {
      setLoading(false);
      Alert.alert('Erro', err.message);
    }
  }

  return (
    <View style={{flex:1, padding:20}}>
      <Text style={{fontSize:20}}>Stake Tokens</Text>
      <TextInput placeholder="Amount (smallest unit)" value={amount} onChangeText={setAmount} style={{borderWidth:1, marginTop:12, padding:8}} />
      <TextInput placeholder="Validator / Node ID" value={validator} onChangeText={setValidator} style={{borderWidth:1, marginTop:12, padding:8}} />
      <View style={{height:12}} />
      <Button title={loading ? 'Enviando...' : 'Confirmar Stake'} onPress={handleStake} />
    </View>
  );
}
