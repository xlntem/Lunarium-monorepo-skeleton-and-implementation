// apps/desktop/renderer/src/App.tsx
import React from 'react';
export default function App(){
  return (
    <div style={{padding:20}}>
      <h1>Lunarium Desktop</h1>
      <p>Use the mobile app for staking and masternode registration in this prototype.</p>
    </div>
  );
}
