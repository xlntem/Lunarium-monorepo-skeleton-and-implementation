// apps/desktop/main.ts
import { app, BrowserWindow } from 'electron';
import * as path from 'path';
function createWindow(){
  const win = new BrowserWindow({
    width: 1024, height: 768,
    webPreferences: { contextIsolation: true }
  });
  win.loadURL('http://localhost:3000'); // serve renderer separately during dev
}
app.whenReady().then(createWindow);
app.on('window-all-closed', ()=> { if (process.platform !== 'darwin') app.quit(); });
